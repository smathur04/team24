
public class RecaptchaConstants {
    public static final String SECRET_KEY ="6LdmDjMrAAAAAN57zjNzapJA3FBkFdmxXT355SLb";

}
