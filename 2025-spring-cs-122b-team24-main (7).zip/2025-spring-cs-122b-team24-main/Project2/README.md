DEMO VIDEO URL:
https://youtu.be/WGLb0WWHQNU

SITE:
http://54.241.154.32:8080/Project2/

TEAM OF ONE

Substring Matching 
Used only LIKE.
This project implements substring search for movie titles, director names, and star names.
User input is wrapped with % wildcards (exampl: %input%), allowing matches to occur anywhere within the text.
No ILIKE was used.
Example: Searching for "king" matches "The Lion King", "Kingdom of Heaven", and "King Arthur" and so on.



